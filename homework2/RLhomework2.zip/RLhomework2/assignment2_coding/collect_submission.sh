rm -f assignment2.zip 
zip -r assignment2.zip "q3_schedule.py" "q4_linear_torch.py" "q5_nature_torch.py"
